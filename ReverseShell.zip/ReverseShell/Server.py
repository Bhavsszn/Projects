import socket

IP_ADDRESS = "0.0.0.0"
PORT = 5003
BUFFER_SIZE = 4096


def start_server():
    server_socket = socket.socket()
    server_socket.bind((IP_ADDRESS, PORT))
    server_socket.listen(1)
    print(f"Listening on {IP_ADDRESS}:{PORT}")

    client_socket, _ = server_socket.accept()
    print("Client connected")

    while True:
        try:
            data = input("> ")
            if not data:
                continue

            client_socket.sendall(data.encode())

            if data.lower() == "exit":
                break

            response = b""
            while True:
                chunk = client_socket.recv(BUFFER_SIZE)
                if not chunk:
                    break
                response += chunk

            output = response.decode().strip()
            if output:
                print(f"Output:\n{output}")
            else:
                print("No output received")

        except KeyboardInterrupt:
            print("\nStopping server...")
            break

    client_socket.close()
    server_socket.close()

start_server()

